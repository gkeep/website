﻿using System;
using System.Windows.Forms;
using System.Data.OleDb;

namespace aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
{
    class Program
    {
        static void Main(string[] args)
        {
            var Catalog = new ADOX.Catalog();

            try
            {
                Catalog.Create("Provider=Microsoft.Jet." + "OLEDB.4.0;Data source=..\\..\\new_BD.mdb");
                MessageBox.Show(@"База данных успешно создана");
            }
            catch (System.Runtime.InteropServices.COMException Exception)
            {
                MessageBox.Show(Exception.Message);
            }
            finally
            {
                Catalog = null;
            }
        }
    }
}
