﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace zad5_edit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var Connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data source=..\\..\\..\\new_BD.mdb");
            Connection.Open();

            var Idx = Int32.Parse(textBox1.Text);
            var Name = textBox2.Text;
            var Phone = textBox3.Text;

            var Command = new OleDbCommand("UPDATE [БД телефонов]" + " SET [ФИО] = ?, [Номер телефона] = ? WHERE [Номер п/п] = ?;", Connection);
            Command.Parameters.AddWithValue("[ФИО]", Name);
            Command.Parameters.AddWithValue("[Номер телефона]", Phone);
            Command.Parameters.AddWithValue("[Номер п/п]", Idx);

            Command.ExecuteNonQuery();
            MessageBox.Show("Запись изменена");
            Connection.Close();
        }
    }
}
