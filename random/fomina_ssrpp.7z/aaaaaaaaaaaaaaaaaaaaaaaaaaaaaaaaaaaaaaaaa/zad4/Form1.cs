﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace zad4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var Connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data source=..\\..\\..\\new_BD.mdb");
            Connection.Open();

            var Command = new OleDbCommand("SELECT * FROM [БД телефонов]", Connection);

            var Reader = Command.ExecuteReader();
            var Table = new DataTable();

            for (int i = 0; i < 3; i++)
                Table.Columns.Add(Reader.GetName(i));

            while (Reader.Read())
            {
                Table.Rows.Add(Reader.GetValue(0), Reader.GetValue(1), Reader.GetValue(2));
            }

            Reader.Close();
            Connection.Close();
            dataGridView1.DataSource = Table;
        }
    }
}
