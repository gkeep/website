﻿using System;
using System.Windows.Forms;
using System.Data.OleDb;

namespace zad2
{
    class Program
    {
        static void Main(string[] args)
        {
            var Connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data source=..\\..\\..\\new_BD.mdb");
            Connection.Open();

            var Command = new OleDbCommand("CREATE TABLE[БД телефонов] ([Номер п/п] counter, [ФИО] char(20), [Номер телефона] char(20))", Connection);

            try
            {
                Command.ExecuteNonQuery();
                MessageBox.Show("Структура записана");
            }
            catch (System.Runtime.InteropServices.COMException Exception)
            {
                MessageBox.Show(Exception.Message);
                Connection.Close();
            }
        }
    }
}
