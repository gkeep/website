﻿using System;
using System.Windows.Forms;
using System.Data.OleDb;

namespace zad3
{
    class Program
    {
        static void Main(string[] args)
        {
            var Connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data source=..\\..\\..\\new_BD.mdb");
            Connection.Open();

            var Command = new OleDbCommand("INSERT INTO [БД телефонов] (ФИО, [Номер телефона]) VALUES ('Света-х', '521-61-41')", Connection);

            Command.ExecuteNonQuery();
            MessageBox.Show("Запись добавлена");
            Connection.Close();
        }
    }
}
