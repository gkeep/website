﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace zad5_add
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var Connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data source=..\\..\\..\\new_BD.mdb");
            Connection.Open();

            var Name = textBox1.Text;
            var Phone = textBox2.Text;

            var Command = new OleDbCommand("INSERT INTO [БД телефонов] (ФИО, [Номер телефона]) VALUES (?, ?);", Connection);
            Command.Parameters.AddWithValue("[ФИО]", Name);
            Command.Parameters.AddWithValue("[Номер телефона]", Phone);

            Command.ExecuteNonQuery();
            MessageBox.Show("Запись добавлена");
            Connection.Close();
        }
    }
}
